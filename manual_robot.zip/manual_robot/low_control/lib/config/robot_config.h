#ifndef ROBOT_CONFIG_H
#define ROBOT_CONFIG_H

#define ROBOT_BASE OMNI
#define USE_BTS7960_DRIVER
#define USE_MPU6050_IMU

#define DEBUG 1

#define K_P = 0.05
#define K_I = 0.9
#define K_D = 0.1

#define MAX_RPM 730
#define COUNTS_PER_REV 247
#define WHEEL_DIAMETER 0.1
#define PWM_BITS 8
#define LR_WHEELS_DISTANCE 0.6
#define FR_WHEELS_DISTANCE 0.6

// Chan encoder
#define MOTOR1_ENCODER_A 15
#define MOTOR1_ENCODER_B 14

#define MOTOR2_ENCODER_A 11
#define MOTOR2_ENCODER_B 12

#define MOTOR3_ENCODER_A 17
#define MOTOR3_ENCODER_B 16

#define MOTOR4_ENCODER_A 9
#define MOTOR4_ENCODER_B 10

// Chan dong co
#ifdef USE_BTS7960_DRIVER
  #define MOTOR_DRIVER BTS7960  

  #define MOTOR1_PWM 1 //DON'T TOUCH THIS! This is just a placeholder
  #define MOTOR1_IN_A 21
  #define MOTOR1_IN_B 20

  #define MOTOR2_PWM 8 //DON'T TOUCH THIS! This is just a placeholder
  #define MOTOR2_IN_A 5
  #define MOTOR2_IN_B 6

  #define MOTOR3_PWM 0 //DON'T TOUCH THIS! This is just a placeholder
  #define MOTOR3_IN_A 22
  #define MOTOR3_IN_B 23

  #define MOTOR4_PWM 2 //DON'T TOUCH THIS! This is just a placeholder
  #define MOTOR4_IN_A 4
  #define MOTOR4_IN_B 3

  #define PWM_MAX pow(2, PWM_BITS) - 1
  #define PWM_MIN -PWM_MAX
#endif