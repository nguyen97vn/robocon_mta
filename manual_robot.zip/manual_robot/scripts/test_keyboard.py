#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Twist
import sys, select, os
if os.name == 'nt':
    import msvcrt
else:
    import tty, termios

MAX_VX = 1.0
MAX_VY = 1.0
STEP_V = 0.1

msg = """
Control Robot manual!
---------------------------
Moving around:
           8
   4     any_key    6
           2

8/2 : increase/decrease linear velocity x
6/4 : increase/decrease linear velocity y

space key, 5 : force stop

CTRL-C to quit
"""

e = """
Communications Failed
"""
def getKey():
    if os.name == 'nt':
        if sys.version_info[0] >= 3:
            return msvcrt.getch().decode()
        else:
            return msvcrt.get()
    
    tty.setraw(sys.stdin.fileno())
    rlist, _, _ = select.select([sys.stdin], [], [], 0.1)
    if rlist:
        key = sys.stdin.read(1)
    else:
        key = ''
    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
    return key

def vels(target_linear_vel_x, target_linear_vel_y):
    return " currently: \t linear vel_x %s\t linear vel_y %s" % (target_linear_vel_x, target_linear_vel_y)

def makeSimpleProfile(output, input, slop):
    if input > output:
        output = min(input, output + slop)
    elif input < output:
        output = max(input, output - slop)
    else:
        output = input 
    return output

def constrain(input, low, high):
    if input < low:
        input = low
    elif input > high:
        input = high
    else:
        input = input
    return input


def checkLinearLimitVelocity_x(velx):
    velx = constrain(velx, -MAX_VX, MAX_VX)
    return velx

def checkLinearLimitVelocity_y(vely):
    vely = constrain(vely, -MAX_VY, MAX_VY)
    return vely

if __name__=="__main__":
    if os.name != 'nt':
        settings = termios.tcgetattr(sys.stdin)
    
    rospy.init_node('test_keyboard')
    pub = rospy.Publisher('turtle1/cmd_vel', Twist, queue_size=10)
    status = 0
    target_linear_vel_x = 0.0
    target_linear_vel_y = 0.0
    
    control_linear_vel_x = 0.0
    control_linear_vel_y = 0.0

    try:
        while(1):
            key = getKey()
            if key == '8':
                target_linear_vel_x = checkLinearLimitVelocity_x(target_linear_vel_x + STEP_V)
                status = status + 1
                print(vels(target_linear_vel_x,target_linear_vel_y))
            if key == '2':
                target_linear_vel_x = checkLinearLimitVelocity_x(target_linear_vel_x - STEP_V)
                status = status + 1
                print(vels(target_linear_vel_x, target_linear_vel_y))
            if key == '6':
                target_linear_vel_y = checkLinearLimitVelocity_y(target_linear_vel_y + STEP_V)
                status = status + 1
                print(vels(target_linear_vel_x, target_linear_vel_y))
            if key == '4':
                target_linear_vel_y = checkLinearLimitVelocity_y(target_linear_vel_y - STEP_V)
                status = status + 1
                print(vels(target_linear_vel_x, target_linear_vel_y)) 

            if key == '9':
                #target_linear_vel_x = 0
                target_linear_vel_y = target_linear_vel_x   
                target_linear_vel_x = checkLinearLimitVelocity_x(target_linear_vel_x + STEP_V)
                target_linear_vel_y = checkLinearLimitVelocity_y(target_linear_vel_y + STEP_V)
                status = status + 1
                print(vels(target_linear_vel_x, target_linear_vel_y)) 

            if key == '1':
                #target_linear_vel_x = 0
                target_linear_vel_y = target_linear_vel_x  
                target_linear_vel_x = checkLinearLimitVelocity_x(target_linear_vel_x - STEP_V)
                target_linear_vel_y = checkLinearLimitVelocity_y(target_linear_vel_y - STEP_V)
                status = status + 1
                print(vels(target_linear_vel_x, target_linear_vel_y))  

            if key == '3':
                #target_linear_vel_x = 0
                target_linear_vel_y = -target_linear_vel_x                  
                target_linear_vel_x = checkLinearLimitVelocity_x(target_linear_vel_x + STEP_V)
                target_linear_vel_y = checkLinearLimitVelocity_y(target_linear_vel_y - STEP_V)
                status = status + 1
                print(vels(target_linear_vel_x, target_linear_vel_y))                            

            if key == '7':
                #target_linear_vel_x = 0
                target_linear_vel_y = -target_linear_vel_x   
                target_linear_vel_x = checkLinearLimitVelocity_x(target_linear_vel_x - STEP_V)
                target_linear_vel_y = checkLinearLimitVelocity_y(target_linear_vel_y + STEP_V)
                status = status + 1
                print(vels(target_linear_vel_x, target_linear_vel_y))                 

            elif key == ' ' or key =='5':
                target_linear_vel_x = 0.0
                target_linear_vel_y = 0.0
                print(vels(target_linear_vel_x, target_linear_vel_y))

            else:
                if (key == '\x03'):
                    break

            if status == 10:
                print(msg)
                status = 0
            twist = Twist()
            control_linear_vel_x = makeSimpleProfile(control_linear_vel_x, target_linear_vel_x, (STEP_V / 2.0))    
            twist.linear.x = control_linear_vel_x

            control_linear_vel_y = makeSimpleProfile(control_linear_vel_y, target_linear_vel_y, (STEP_V / 2.0))    
            twist.linear.y = control_linear_vel_y 
            twist.linear.z = 0
            twist.angular.x = 0; twist.angular.y = 0; twist.angular.z = 0

            pub.publish(twist)

    except:
        print(e)
    finally:
        twist = Twist()
        twist.linear.x = 0.0; twist.linear.y = 0.0; twist.linear.z = 0.0
        twist.angular.x = 0.0; twist.angular.y = 0.0; twist.angular.z = 0.0
        pub.publish(twist)

    if os.name != 'nt':
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)                  

