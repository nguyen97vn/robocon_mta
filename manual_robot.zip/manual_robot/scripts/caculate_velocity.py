#!/usr/bin/env python
import rospy
import roslib
from math import sin, cos, pi
roslib.load_manifest('manual_robot')

from geometry_msgs.msg import Twist
from std_msgs.msg import Int16
from std_msgs.msg import Float32
from manual_robot.msg import my_msg 

pi = 3.141592654
d = 0.1
v1 = 0.0; v2 = 0.0; v3 = 0.0; v4 = 0.0
Vdx = 0.0; Vdy = 0.0; Th_d = 0.0; V_th = 0.0
PWM_1 = 0; PWM_2 = 0; PWM_3 = 0; PWM_4 = 0
PWM_1A = 0; PWM_2A = 0; PWM_3A = 0; PWM_4A = 0
PWM_1B = 0; PWM_2B = 0; PWM_3B = 0; PWM_4B = 0

def VelocityCallback(msg):
    global Vdx, Vdy, V_th 
    x = msg.linear.x 
    y = - msg.linear.y 
    z = - msg.angular.z 
    if x != 0 and y == 0:
        Vdx = x 
    if y != 0 and x == 0:
        Vdy = y 
    if x == 0 and y == 0:
        V_th = z 
    if x != 0 and y != 0 and z == 0:
        Vdx = x
    if x == 0 and y == 0 and z == 0:
        Vdx = 0
        Vdy = 0
        Vdz = 0
def caculate_velocity(th_d, vd, v_th):
    global v1, v2, v3, v4 
    v1 = vd*sin(th_d + pi/4) + v_th
    v2 = vd*cos(th_d + pi/4) - v_th
    v3 = vd*cos(th_d + pi/4) + v_th
    v4 = vd*sin(th_d + pi/4) - v_th
    print("v1: ",v1)
    print("v2: ",v2)
    print("v3: ",v3)
    print("v4: ",v4)
    return v1, v2, v3, v4

def MAIN_LOOP():
    global Vdx, Vdy, V_th, pi, PWM_1, PWM_2, PWM_3, PWM_4  
    global PWM_1A, PWM_2A, PWM_3A, PWM_4A
    global PWM_1B, PWM_2B, PWM_3B, PWM_4B 
    rospy.init_node("caculate_velocity")
    pwm_pub = rospy.Publisher('pwm',my_msg, queue_size=10)
    sub_vel = rospy.Subscriber('cmd_vel',Twist,VelocityCallback)
    rate = rospy.Rate(10)
    while not rospy.is_shutdown():
        rospy.loginfo(Vdx)
        if Vdx != 0 and Vdy == 0 and V_th == 0:
            caculate_velocity(0.0, Vdx, 0.0)
        if Vdx !=0 and Vdy !=0 and (Vdx*Vdy) > 0:
            caculate_velocity(pi/4, Vdx, 0)
        if Vdy != 0 and Vdx == 0 and V_th ==0:
            caculate_velocity(pi/2, Vdy, 0)
        if Vdx != 0 and Vdy != 0 and (Vdx*Vdy) < 0:
            caculate_velocity(-pi/4, Vdy, 0)
        if (Vdx == 0 and Vdy == 0 and V_th != 0):
            caculate_velocity(0, 0, V_th)
        
        if PWM_1 >= 255:
            PWM_1 = 255
        elif PWM_1 <= -255:
            PWM_1 = -255
        else:
            PWM_1 = (255*60*v1)/(730*pi*d)
            PWM_1 = int(PWM_1)


        if PWM_2 >= 255:
            PWM_2 = 255
        elif PWM_2 <= -255:
            PWM_2 = -255
        else:
            PWM_2 = (255*60*v2)/(730*pi*d)
            PWM_2 = int(PWM_2)


        if PWM_3 >= 255:
            PWM_3 = 255
        elif PWM_3 <= -255:
            PWM_3 = -255
        else:
            PWM_3 = (255*60*v3)/(730*pi*d)
            PWM_3 = int(PWM_3)


        if PWM_4 >= 255:
            PWM_4 = 255
        elif PWM_4 <= -255:
            PWM_4 = -255
        else:
            PWM_4 = (255*60*v4)/(730*pi*d)
            PWM_4 = int(PWM_4) 

        if PWM_1 > 0:
            PWM_1A = PWM_1 
            PWM_1B = 0
        elif PWM_1 < 0:
            PWM_1B = abs(PWM_1)
            PWM_1A = 0
        else:
            PWM_1A = 0 
            PWM_1B = 0

        if PWM_2 > 0:
            PWM_2A = PWM_2 
            PWM_2B = 0
        elif PWM_2 < 0:
            PWM_2B = abs(PWM_2)
            PWM_2A = 0
        else:
            PWM_2A = 0 
            PWM_2B = 0 

        if PWM_3 > 0:
            PWM_3A = PWM_3 
            PWM_3B = 0
        elif PWM_3 < 0:
            PWM_3B = abs(PWM_3)
            PWM_3A = 0
        else:
            PWM_3A = 0 
            PWM_3B = 0 

        if PWM_4 > 0:
            PWM_4A = PWM_4 
            PWM_4B = 0
        elif PWM_4 < 0:
            PWM_4B = abs(PWM_4)
            PWM_4A = 0
        else:
            PWM_4A = 0 
            PWM_4B = 0  

        if Vdx == 0 and Vdy == 0 and V_th == 0:
            PWM_1A = 0
            PWM_1B = 0
            PWM_2A = 0
            PWM_2B = 0
            PWM_3A = 0
            PWM_3B = 0
            PWM_4A = 0
            PWM_4B = 0

        #print("PWM_1: ",PWM_1)
        pwm_value = my_msg()
        pwm_value.pwm1a.data = PWM_1A 
        pwm_value.pwm1b.data = PWM_1B 
        pwm_value.pwm2a.data = PWM_2A 
        pwm_value.pwm2b.data = PWM_2B 
        pwm_value.pwm3a.data = PWM_3A 
        pwm_value.pwm3b.data = PWM_3B 
        pwm_value.pwm4a.data = PWM_4A 
        pwm_value.pwm4b.data = PWM_4B   
        pwm_pub.publish(pwm_value) 
        rate.sleep()
if __name__ == '__main__':
    try:
        MAIN_LOOP()
    except rospy.ROSInterruptException:
        pass                                                              
        
