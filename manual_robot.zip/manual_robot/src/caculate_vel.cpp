#include "ros/ros.h"
#include <std_msgs/Int16.h>
#include <std_msgs/Float32.h>
#include <geometry_msgs/Twist.h>
#include <ros/time.h>
#include <cmath> 
#include <manual_robot/my_msg.h>

float pi = 3.141592654, d = 0.1, v1 = 0.0, v2 = 0.0, v3 = 0.0, v4 = 0.0;
float Vdx = 0.0, Vdy = 0.0, Th_d = 0.0, V_th = 0.0;
int PWM_1 = 0, PWM_2 = 0, PWM_3 = 0, PWM_4 = 0;
int PWM_1A = 0, PWM_2A = 0, PWM_3A = 0, PWM_4A = 0;
int PWM_1B = 0, PWM_2B = 0, PWM_3B = 0, PWM_4B = 0;
 
void velocityCallback(const geometry_msgs::Twist& cmd_msg){
    float x = 0.0;
    float y = 0.0;
    float z = 0.0;
    x = cmd_msg.linear.x;    
    y = -cmd_msg.linear.y;    
    z = -cmd_msg.angular.z;
    if (x != 0 && y == 0){
        Vdx = x;
        // Vdy = 0;
        // V_th = 0;
    }
    if (y != 0 && x == 0){
        Vdy = y;
        // Vdx = 0;
        // V_th = 0;
    }
    if (x == 0 && y == 0 && z != 0){
        V_th = z;
        // Vdx = 0;
        // Vdy = 0;
    }
    if ( x != 0 && y != 0 && z == 0){
        Vdx = x;
    }
    if ( x == 0 && y == 0 && z == 0){
        Vdx = 0;
        Vdy = 0;
        V_th = 0;
    }
    // return Vdx, Vdy, V_th;
}

float caculate_velocity(float th_d, float vd, float v_th){
    v1 = vd*sin(th_d + pi/4) + v_th;
    v2 = vd*cos(th_d + pi/4) - v_th;
    v3 = vd*cos(th_d + pi/4) + v_th;
    v4 = vd*sin(th_d + pi/4) - v_th;
    return v1, v2, v3, v4; 
}
int main(int argc, char** argv){
    ros::init(argc, argv, "caculate_vel");
    ros::NodeHandle nh;
    // ros::Publisher pwm_pub = nh.advertise<manual_robot::my_msg>("pwm",100);
    ros::Publisher pwm_pub = nh.advertise<manual_robot::my_msg>("pwm", 100);
    ros::Subscriber sub_vel = nh.subscribe("cmd_vel", 100, velocityCallback);
    //ros::Subscriber<geometry_msgs::Twist>sub_vel("cmd_vel", velocityCallback);

    ros::Rate loop_rate(10);
    while (ros::ok()){
        if ( Vdx != 0 && Vdy == 0 and V_th == 0){ // chay thang x
            caculate_velocity(0.0, Vdx, 0.0);
        }
        if (Vdx != 0 && Vdy != 0 && (Vdx*Vdy) > 0){ // chay cheo 1
            caculate_velocity(pi/4, Vdx, 0.0);
        }
        if (Vdy != 0 && Vdx == 0 && V_th == 0){ // chay thang y
            caculate_velocity(pi/2, Vdy, 0.0);
        }
        if ( Vdx != 0 && Vdy != 0 && V_th == 0 && (Vdx*Vdy) < 0){ // chay cheo 2
            caculate_velocity(-pi/4, Vdy, 0.0);
        }
        if (Vdx == 0 && Vdy == 0 && V_th != 0){  // xoay tai cho
            caculate_velocity(0.0, 0.0, V_th);
        }

        if (PWM_1 >= 255){
            PWM_1 = 255;
        }
        else if (PWM_1 <= -255){
            PWM_1 = -255;
        }
        else {
            PWM_1 = (255*60*v1)/(730*pi*d);
            PWM_1 = int(PWM_1);
        }

        if (PWM_2 >= 255){
            PWM_2 = 255;
        }
        else if (PWM_2 <= -255){
            PWM_2 = -255;
        }
        else {
            PWM_2 = (255*60*v2)/(730*pi*d);
            PWM_2 = int(PWM_2);
        }

        if (PWM_3 >= 255){
            PWM_3 = 255;
        }
        else if (PWM_3 <= -255){
            PWM_3 = -255;
        }
        else {
            PWM_3 = (255*60*v3)/(730*pi*d);
            PWM_3 = int(PWM_3);
        }

        if (PWM_4 >= 255){
            PWM_4 = 255;
        }
        else if (PWM_4 <= -255){
            PWM_4 = -255;
        }
        else {
            PWM_4 = (255*60*v4)/(730*pi*d);
            PWM_4 = int(PWM_4);
        }

        if (v1 > 0){
            PWM_1A = abs(PWM_1);
            PWM_1B = 0;
        }
        else if (v1 < 0){
            PWM_1B = abs(PWM_1);
            PWM_1A = 0;
        }
        else {
            PWM_1A = 0;
            PWM_1B = 0;
        }

        if (v2 > 0){
            PWM_2A = abs(PWM_2);
            PWM_2B = 0;
        }
        else if (v2 < 0){
            PWM_2B = abs(PWM_2);
            PWM_2A = 0;
        }
        else {
            PWM_2A = 0;
            PWM_2B = 0;
        }

        if (v3 > 0){
            PWM_3A = abs(PWM_3);
            PWM_3B = 0;
        }
        else if (v3 < 0){
            PWM_3B = abs(PWM_3);
            PWM_3A = 0;
        }
        else {
            PWM_3A = 0;
            PWM_3B = 0;
        }

        if (v4 > 0){
            PWM_4A = abs(PWM_4);
            PWM_4B = 0;
        }
        else if (v4 < 0){
            PWM_4B = abs(PWM_4);
            PWM_4A = 0;
        }
        else {
            PWM_4A = 0;
            PWM_4B = 0;
        } 
        if (Vdx == 0 && Vdy == 0 && V_th == 0){
            PWM_1A = 0;
            PWM_1B = 0;
            PWM_2A = 0;
            PWM_2B = 0;
            PWM_3A = 0;
            PWM_3B = 0;
            PWM_4A = 0;
            PWM_4B = 0;
        }       
        manual_robot::my_msg pwm_value;
        pwm_value.pwm1a.data = PWM_1A;
        pwm_value.pwm1b.data = PWM_1B;
        pwm_value.pwm2a.data = PWM_2A;
        pwm_value.pwm2b.data = PWM_2B;
        pwm_value.pwm3a.data = PWM_3A;
        pwm_value.pwm3b.data = PWM_3B;
        pwm_value.pwm4a.data = PWM_4A;
        pwm_value.pwm4b.data = PWM_4B;  
        pwm_pub.publish(pwm_value);
        ros::spinOnce();
        loop_rate.sleep();   
    }
}