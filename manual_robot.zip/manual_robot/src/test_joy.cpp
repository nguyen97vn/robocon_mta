#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <sensor_msgs/Joy.h>

#include <manual_robot/pwm.h>
class TeleopRobot
{
public:
  TeleopRobot();

private:
  void joyCallback(const sensor_msgs::Joy::ConstPtr& joy);
  
  ros::NodeHandle nh_;

  int linear_x_, linear_y_, angular_;
  int xilanh1_, xilanh2_, xilanh3_, xilanh4_;
  double l_scale_, a_scale_;
  ros::Publisher vel_pub_;
  ros::Publisher signals_pub;
  ros::Subscriber joy_sub_;

};


TeleopRobot::TeleopRobot():
  linear_x_(1),
  angular_(2),
  linear_y_(3),
  xilanh1_(4),
  xilanh2_(5),
  xilanh3_(6),
  xilanh4_(7)
{

  nh_.param("axis_linear_x", linear_x_, linear_x_);
  nh_.param("axis_linear_y", linear_y_, linear_y_);
  nh_.param("axis_angular", angular_, angular_);
  nh_.param("scale_angular", a_scale_, a_scale_);
  nh_.param("scale_linear", l_scale_, l_scale_);

  nh_.param("buttons_xilanh_1",xilanh1_,xilanh1_);
  nh_.param("buttons_xilanh_2",xilanh2_,xilanh2_);
  nh_.param("buttons_xilanh_3",xilanh3_,xilanh3_);
  nh_.param("buttons_xilanh_4",xilanh4_,xilanh4_);
  vel_pub_ = nh_.advertise<geometry_msgs::Twist>("cmd_vel", 1);
  signals_pub = nh_.advertise<manual_robot::pwm>("signals",10);

  joy_sub_ = nh_.subscribe<sensor_msgs::Joy>("joy", 10, &TeleopRobot::joyCallback, this);

}

void TeleopRobot::joyCallback(const sensor_msgs::Joy::ConstPtr& joy)
{
  geometry_msgs::Twist twist;
  twist.angular.z = a_scale_*joy->axes[angular_];
  twist.linear.x = l_scale_*joy->axes[linear_x_];
  twist.linear.y = l_scale_*joy->axes[linear_y_];

  manual_robot::pwm msg;
  msg.pwm1a.data = joy->buttons[xilanh1_];
  msg.pwm2a.data = joy->buttons[xilanh2_];
  msg.pwm3a.data = joy->buttons[xilanh3_];
  msg.pwm4a.data = joy->buttons[xilanh4_];
  vel_pub_.publish(twist);
  signals_pub.publish(msg);
}


int main(int argc, char** argv)
{
  ros::init(argc, argv, "teleop_robot");
  TeleopRobot teleop_robot;

  ros::spin();
}
